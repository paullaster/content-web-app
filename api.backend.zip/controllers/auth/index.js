import register from './register';
import login from './login';

const Accounts = {
    new: register,
    login: login,
};
export default Accounts;